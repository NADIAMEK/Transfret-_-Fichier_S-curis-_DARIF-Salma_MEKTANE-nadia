package securefile;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.HexFormat;

public class CryptoUtils {
    // Clé AES partagée (16 bytes = 128 bits). Ici en hex (32 caractères hex).
    // CHANGE-THIS pour ton projet local; garder la même chaîne côté client et serveur.
    private static final String AES_KEY_HEX = "00112233445566778899aabbccddeeff"; // exemple
    private static final byte[] AES_KEY = HexFormat.of().parseHex(AES_KEY_HEX);

    private static final String AES_ALGO = "AES/ECB/PKCS5Padding"; // conformément à l'énoncé

    public static byte[] encrypt(byte[] plain) throws Exception {
        SecretKeySpec keySpec = new SecretKeySpec(AES_KEY, "AES");
        Cipher cipher = Cipher.getInstance(AES_ALGO);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec);
        return cipher.doFinal(plain);
    }

    public static byte[] decrypt(byte[] cipherBytes) throws Exception {
        SecretKeySpec keySpec = new SecretKeySpec(AES_KEY, "AES");
        Cipher cipher = Cipher.getInstance(AES_ALGO);
        cipher.init(Cipher.DECRYPT_MODE, keySpec);
        return cipher.doFinal(cipherBytes);
    }

    public static byte[] sha256(byte[] data) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return md.digest(data);
    }

    public static String sha256Hex(byte[] data) throws Exception {
        return HexFormat.of().formatHex(sha256(data));
    }

    public static String sha256HexOfFile(File f) throws Exception {
        byte[] bytes = Files.readAllBytes(f.toPath());
        return sha256Hex(bytes);
    }

    public static byte[] readAllBytes(File f) throws IOException {
        return Files.readAllBytes(f.toPath());
    }

    // utilitaire: convert hex string to readable hex of bytes
    public static String bytesToHex(byte[] b) {
        return HexFormat.of().formatHex(b);
    }
}
