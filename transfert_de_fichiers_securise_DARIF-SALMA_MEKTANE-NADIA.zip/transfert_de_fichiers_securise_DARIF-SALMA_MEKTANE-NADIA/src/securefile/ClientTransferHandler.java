package securefile;

import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

public class ClientTransferHandler implements Runnable {

    private final Socket socket;
    private final Map<String, String> credentials;
    private final Path storageDir = Path.of("received_files");

    public ClientTransferHandler(Socket socket, Map<String, String> credentials) {
        this.socket = socket;
        this.credentials = credentials;

        // Crée le dossier received_files si il n'existe pas
        try {
            if (!Files.exists(storageDir)) {
                Files.createDirectories(storageDir);
                System.out.println("Dossier received_files créé automatiquement.");
            }
        } catch (IOException e) {
            System.err.println("Impossible de créer le dossier received_files : " + e.getMessage());
        }
    }

    @Override
    public void run() {
        try (DataInputStream in = new DataInputStream(socket.getInputStream());
             DataOutputStream out = new DataOutputStream(socket.getOutputStream())) {

            // --- Phase 1 : Authentification
            String login = in.readUTF();
            String pwd = in.readUTF();
            System.out.println("Auth attempt: " + login);

            if (!credentials.containsKey(login) || !credentials.get(login).equals(pwd)) {
                out.writeUTF("AUTH_FAIL");
                out.flush();
                System.out.println("Auth fail, connection closed.");
                return;
            }
            out.writeUTF("AUTH_OK");
            out.flush();

            // --- Phase 2 : Négociation
            String filename = in.readUTF();
            long originalSize = in.readLong();
            String sha256hex = in.readUTF();

            System.out.printf("Preparing to receive: %s (%d bytes), sha256=%s%n", filename, originalSize, sha256hex);
            out.writeUTF("READY_FOR_TRANSFER");
            out.flush();

            // --- Phase 3 : Transfert
            long encLen = in.readLong();
            if (encLen > Integer.MAX_VALUE) {
                out.writeUTF("TRANSFER_FAIL");
                out.flush();
                System.err.println("File too big: " + filename);
                return;
            }

            byte[] encBytes = new byte[(int) encLen];
            in.readFully(encBytes);

            // Déchiffrage AES
            byte[] plainBytes;
            try {
                plainBytes = CryptoUtils.decrypt(encBytes);
            } catch (Exception e) {
                e.printStackTrace();
                out.writeUTF("TRANSFER_FAIL");
                out.flush();
                return;
            }

            // Sauvegarder le fichier
            Path outPath = storageDir.resolve(filename);
            Files.write(outPath, plainBytes);

            // Vérifier SHA-256 + taille
            String computedHash = CryptoUtils.sha256Hex(plainBytes);
            if (computedHash.equalsIgnoreCase(sha256hex) && plainBytes.length == originalSize) {
                out.writeUTF("TRANSFER_SUCCESS");
                out.flush();
                System.out.println("Received and verified: " + outPath);
            } else {
                out.writeUTF("TRANSFER_FAIL");
                out.flush();
                System.err.printf("Hash/size mismatch: expected %s/%d, computed %s/%d%n",
                        sha256hex, originalSize, computedHash, plainBytes.length);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try { socket.close(); } catch (IOException ignored) {}
        }
    }
}
