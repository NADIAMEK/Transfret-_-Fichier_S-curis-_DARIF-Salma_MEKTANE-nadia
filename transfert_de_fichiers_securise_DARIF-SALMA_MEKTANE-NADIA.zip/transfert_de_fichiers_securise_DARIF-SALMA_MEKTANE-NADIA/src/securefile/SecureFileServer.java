package securefile;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class SecureFileServer {
    private final int port;
    private final Map<String,String> credentials = new HashMap<>(); // login -> password (stocké en dur)

    public SecureFileServer(int port) {
        this.port = port;
        // Exemple d'utilisateurs (adapter)
        credentials.put("nadia","nadiapass");
        credentials.put("salma","salmapass");
    }

    public void start() throws IOException {
        ServerSocket serverSocket = new ServerSocket(port);
        System.out.println("SecureFileServer running on port " + port);
        while (true) {
            Socket client = serverSocket.accept();
            System.out.println("Connection from " + client.getInetAddress());
            new Thread(new ClientTransferHandler(client, credentials)).start();
        }
    }

    public static void main(String[] args) throws IOException {
        int port = 9000;
        if (args.length >= 1) port = Integer.parseInt(args[0]);
        SecureFileServer server = new SecureFileServer(port);
        server.start();
    }

}
