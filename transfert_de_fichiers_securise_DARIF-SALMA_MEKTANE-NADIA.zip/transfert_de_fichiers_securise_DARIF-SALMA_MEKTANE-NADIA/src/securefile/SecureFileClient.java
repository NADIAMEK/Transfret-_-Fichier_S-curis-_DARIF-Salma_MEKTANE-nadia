package securefile;

import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;

public class SecureFileClient {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Server IP (default 127.0.0.1): ");
        String host = sc.nextLine().isBlank() ? "127.0.0.1" : sc.nextLine();
        System.out.print("Server port (default 9000): ");
        String portLine = sc.nextLine();
        int port = portLine.isBlank() ? 9000 : Integer.parseInt(portLine);
        System.out.print("Login: ");
        String login = sc.nextLine();
        System.out.print("Password: ");
        String pwd = sc.nextLine();
        System.out.print("Path to file to send: ");
        String path = sc.nextLine();

        // quick fallback if user accidentally pressed enter earlier:
        if (host == null || host.isBlank()) host = "127.0.0.1";

        try (Socket socket = new Socket(host, port);
             DataOutputStream out = new DataOutputStream(socket.getOutputStream());
             DataInputStream in = new DataInputStream(socket.getInputStream())) {

            // Phase 1: Auth
            out.writeUTF(login);
            out.writeUTF(pwd);
            out.flush();
            String authResp = in.readUTF();
            if (!"AUTH_OK".equals(authResp)) {
                System.err.println("Authentication failed: " + authResp);
                return;
            }
            System.out.println("Authenticated.");

            // Pré-traitement: calcul SHA-256 et chiffrement
            Path f = Path.of(path);
            if (!Files.exists(f)) {
                System.err.println("Fichier introuvable: " + path);
                return;
            }
            byte[] plain = Files.readAllBytes(f);
            String shaHex = CryptoUtils.sha256Hex(plain);
            byte[] enc = CryptoUtils.encrypt(plain);

            // Phase 2: Envoi metadonnées
            out.writeUTF(f.getFileName().toString());
            out.writeLong(plain.length);
            out.writeUTF(shaHex);
            out.flush();
            String ready = in.readUTF();
            if (!"READY_FOR_TRANSFER".equals(ready)) {
                System.err.println("Server not ready: " + ready);
                return;
            }

            // Phase 3: Envoi fichier chiffré
            out.writeLong(enc.length);
            out.write(enc);
            out.flush();

            String result = in.readUTF();
            System.out.println("Server response: " + result);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
